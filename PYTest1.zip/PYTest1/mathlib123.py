def cal_square(num):
    return num * num